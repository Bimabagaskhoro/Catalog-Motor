package com.example.catalogmotor.data;

import com.example.catalogmotor.R;
import com.example.catalogmotor.model.MotorBebek;
import com.example.catalogmotor.model.MotorMatic;
import com.example.catalogmotor.model.MotorSport;

import java.util.ArrayList;

public class DataDummy {
    public static ArrayList<MotorBebek> generateDummyBebek() {
        ArrayList<MotorBebek> courses = new ArrayList<>();
        courses.add(new MotorBebek(
                "1",
                "Jupiter z1",
                "Yamaha",
                "4 stroke, Single selinder",
                "4 percepatan",
                "124cc",
                "7,4 kw / 7.750 rpm",
                "Karburator",
                "3,5 liter",
                "Rp. 16.000.000",
                "https://www.yamaha-motor.co.id/uploads/products/AVobVmS04nBsvDMy9HMc.png"
                ));
        courses.add(new MotorBebek(
                "2",
                "Revo x",
                "Honda",
                "4 stroke, Single selinder",
                "4 percepatan",
                "125cc",
                "6,56 kw / 7.500 rpm",
                "Fuel injection",
                "4,0 liter",
                "Rp. 12.000.000",
                "https://www.semisena.com/wp-content/uploads/2017/10/Motor-Honda-Revo-X.jpg"
        ));
        courses.add(new MotorBebek(
                "3",
                "Sonic 150",
                "Honda",
                "4 stroke, Single selinder",
                "6 percepatan",
                "148cc",
                "13.6 kw / 10,000 rpm",
                "Fuel injection",
                "4,0 liter",
                "Rp. 21.000.000",
                "https://hondakompomotor.com/wp-content/uploads/2017/11/AGRESSO-MATTE-BLACK.jpg"
        ));
        courses.add(new MotorBebek(
                "4",
                "New satria FU 150",
                "Suzuki",
                "4 stroke, Single selinder",
                "6 percepatan",
                "148cc",
                "13.6 kw / 10,000 rpm",
                "Fuel injection",
                "4,0 liter",
                "Rp. 23.000.000",
                "https://www.suzuki.co.id//assets/static/img/variant/Satria-BLUEGP.png"
        ));
        courses.add(new MotorBebek(
                "5",
                "Jupiter MX King 150",
                "Yamaha",
                "4 stroke, Single selinder",
                "5 percepatan",
                "148cc",
                "11.5 kw / 8,500 rpm",
                "Fuel injection",
                "3,7 liter",
                "Rp. 18.900.000",
                "https://d2pa5gi5n2e1an.cloudfront.net/global/images/product/motorcycle/Yamaha_Jupiter_MX_King_150/Yamaha_Jupiter_MX_King_150_L_3.jpg"
        ));
        courses.add(new MotorBebek(
                "6",
                "Blade 125 f",
                "Honda",
                "4 stroke, Single selinder",
                "4 percepatan",
                "125cc",
                "7,4 kw / 8.000 rpm",
                "Fuel injection",
                "3,5 liter",
                "Rp. 17.000.000",
                "https://d2pa5gi5n2e1an.cloudfront.net/global/images/product/motorcycle/Honda_Blade_125_FI/Honda_Blade_125_FI_L_1.jpg"
        ));
        courses.add(new MotorBebek(
                "7",
                "GTR 150",
                "Honda",
                "4 stroke, Single selinder",
                "6 percepatan",
                "149cc",
                "12 kw / 9.000 rpm",
                "Fuel injection",
                "3,5 liter",
                "Rp. 21.000.000",
                "https://imgx.motorplus-online.com/crop/0x0:0x0/700x465/photo/2019/09/23/230122270.jpg"
        ));
        courses.add(new MotorBebek(
                "8",
                "Supra x 125 fi",
                "Honda",
                "4 stroke, Single selinder",
                "4 percepatan",
                "124cc",
                "7,4 kw / 8.000 rpm",
                "Fuel injection",
                "3,5 liter",
                "Rp. 17.000.000",
                "https://cdn0-production-images-kly.akamaized.net/QbYVo9CS2CJxhhhFQJMnDmLQ4q4=/640x360/smart/filters:quality(75):strip_icc():format(jpeg)/kly-media-production/medias/2747152/original/088219600_1552155797-AHM_Honda_Supra_X_125_FI._06_.jpg"
        ));
        courses.add(new MotorBebek(
                "9",
                "Vega force",
                "Yamaha",
                "4 stroke, Single selinder",
                "4 percepatan",
                "110cc",
                "6,4 kw / 7.000 rpm",
                "Fuel injection",
                "3,5 liter",
                "Rp. 15.000.000",
                "https://cdn.moladin.com/motor/yamaha/Yamaha_Vega_Force_2066_89605_thumbnail.jpg"
        ));
        courses.add(new MotorBebek(
                "10",
                "Smash 115 fi",
                "Suzuki",
                "4 stroke, Single selinder",
                "4 percepatan",
                "123cc",
                "7,4 kw / 8.000 rpm",
                "Fuel injection",
                "3,5 liter",
                "Rp. 13.000.000",
                "https://i1.wp.com/monkeymotoblog.com/wp-content/uploads/2017/03/SMASH-R-Hijau.jpg"
        ));
        return courses;
    }
    public static ArrayList<MotorSport> generateDummySport() {
        ArrayList<MotorSport> courses = new ArrayList<>();
        courses.add(new MotorSport(
               "1",
                "Xabre",
                "Yamaha",
                "4 stroke, Single selinder",
                "6 percepatan",
                "150cc",
                "12 kw / 8.500 rpm",
                "Fuel Injection",
                "12 liter",
                "Rp. 31.000.000",
                "https://www.yamaha-motor.co.id/uploads/products/2019092413160548370Z84140.png"
        ));
        courses.add(new MotorSport(
                "2",
                "Vixion",
                "Yamaha",
                "4 stroke, Single selinder",
                "6 percepatan",
                "150cc",
                "12 kw / 8.500 rpm",
                "Fuel Injection",
                "12 liter",
                "Rp. 27.000.000",
                "https://www.yamaha-motor.co.id/uploads/products/2019081517240110182C65324.png"
        ));
        courses.add(new MotorSport(
                "3",
                "R25",
                "Yamaha",
                "4 stroke, 2 selinder",
                "6 percepatan",
                "250cc",
                "26 kw / 12.000 rpm",
                "Fuel Injection",
                "14 liter",
                "Rp. 60.000.000",
                "https://imgx.motorplus-online.com/crop/0x0:0x0/700x465/photo/gridoto/2018/04/22/2424149276.jpg"
        ));
        courses.add(new MotorSport(
                "4",
                "Motobi 152",
                "Beneli",
                "4 stroke, Single selinder",
                "5 percepatan",
                "125 cc",
                "11 kw / 6000rpm",
                "Karburator",
                "12 liter",
                "Rp. 18.000.000",
                "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRGb70UhFO-S8McAkX7YmbIZzQ2I5nUg8yQQXjVjPCbCJa5iidc&s"
        ));
        courses.add(new MotorSport(
                "5",
                "Byson",
                "Yamaha",
                "4 stroke, Single selinder",
                "5 percepatan",
                "150 cc",
                "9,6 kw / 6.000 rpm",
                "Fuel Injection",
                "14 liter",
                "Rp. 23.000.000",
                "https://d2pa5gi5n2e1an.cloudfront.net/global/images/product/motorcycle/Yamaha_Byson_FI/Yamaha_Byson_FI_L_1.jpg"
        ));
        courses.add(new MotorSport(
                "6",
                "CB150R STREET FIRE",
                "Honda",
                "4 stroke, Single selinder",
                "6 percepatan",
                "150 cc",
                "9,6 kw / 6.000 rpm",
                "Fuel Injection",
                "14 liter",
                "Rp. 26.000.000",
                "https://www.hondacengkareng.com/wp-content/uploads/2018/11/honda-new-cb150r-streetfire-wild-black-2.jpg"
        ));
        courses.add(new MotorSport(
                "7",
                "GSX-R150",
                "Suzuki",
                "4 stroke, Single selinder",
                "6 percepatan",
                "150 cc",
                "14 kw / 9.500 rpm",
                "Fuel Injection",
                "12 liter",
                "Rp. 27.000.000",
                "https://image.cermati.com/v1557473539/kmjkgebue997eyypy4j2.jpg"
        ));
        courses.add(new MotorSport(
                "8",
                "All new yamaha r15",
                "Yamaha",
                "4 stroke, Single selinder",
                "6 percepatan",
                "155 cc",
                "14,2 kw / 8.700 rpm",
                "Fuel Injection",
                "14 liter",
                "Rp. 35.000.000",
                "https://www.yamaha-motor.co.id/uploads/products/OhrSbwzgKzW6scraO13g.png"
        ));
        courses.add(new MotorSport(
                "9",
                "CBR150R",
                "Honda",
                "4 stroke, Single selinder",
                "6 percepatan",
                "155 cc",
                "12 kw / 8.000 rpm",
                "Fuel Injection",
                "14 liter",
                "Rp. 30.000.000",
                "https://imgx.gridoto.com/crop/256x111:1713x1083/700x465/photo/gridoto/2018/10/18/434813980.jpg"
        ));
        courses.add(new MotorSport(
                "10",
                "W175",
                "Kawasaki",
                "4 stroke, Single selinder",
                "5 percepatan",
                "177cc",
                "6,6 kw / 7500 rpm",
                "karburator",
                "14 liter",
                "Rp. 30.000.000",
                "https://imgx.motorplus-online.com/crop/0x0:0x0/700x465/photo/gridoto/2017/11/19/3217728552.jpg"
        ));
        return courses;
    }
    public static ArrayList<MotorMatic> generateDummyMatic() {
        ArrayList<MotorMatic> courses = new ArrayList<>();
        courses.add(new MotorMatic(
                "1",
                "Aerox 155",
                "Yamaha",
                "4 stroke, Single selinder",
                "V-belt automatic",
                "155cc",
                "11 kw / 8.000 rpm",
                "Fuel injection",
                "5 liter",
                "Rp. 25.000.000",
                "https://d2pa5gi5n2e1an.cloudfront.net/global/images/product/motorcycle/Yamaha_AEROX_155_VVA/Yamaha_AEROX_155_VVA_L_1.jpg"
        ));
        courses.add(new MotorMatic(
                "2",
                "Fino grande",
                "Yamaha",
                "4 stroke, Single selinder",
                "V-belt automatic",
                "125cc",
                "7 kw / 8.000 rpm",
                "Fuel injection",
                "4 liter",
                "Rp. 19.000.000",
                "https://www.yamaha-motor.co.id/uploads/products/H8BzeqLvkjmhpJb1YXhm.png"
        ));
        courses.add(new MotorMatic(
                "3",
                "Lexi",
                "Yamaha",
                "4 stroke, Single selinder",
                "V-belt automatic",
                "125cc",
                "7 kw / 8.000 rpm",
                "Fuel injection",
                "5 liter",
                "Rp. 24.000.000",
                "https://www.yamaha-motor.co.id/assets/lexi/img/motor/31.png"
        ));
        courses.add(new MotorMatic(
                "4",
                "NMAX",
                "Yamaha",
                "4 stroke, Single selinder",
                "V-belt automatic",
                "155cc",
                "11 kw / 8.000 rpm",
                "Fuel injection",
                "5 liter",
                "Rp. 28.000.000",
                "https://imgx.gridoto.com/crop/0x5:1280x975/700x465/photo/2019/11/28/2274545489.jpg"
        ));
        courses.add(new MotorMatic(
                "5",
                "PCX 150",
                "Honda",
                "4 stroke, Single selinder",
                "V-belt automatic",
                "155cc",
                "11 kw / 8.000 rpm",
                "PGM-FI",
                "8 liter",
                "Rp. 30.000.000",
                "https://cdn.moladin.com/motor/honda/Honda_PCX_150_All_New_14950_89267_large_mobile.jpg"
        ));
        courses.add(new MotorMatic(
                "6",
                "Scoopy",
                "Honda",
                "4 stroke, Single selinder",
                "V-belt automatic",
                "110cc",
                "6,7 kw / 7.500 rpm",
                "PGM-FI",
                "4 liter",
                "Rp. 19.000.000",
                "https://d2pa5gi5n2e1an.cloudfront.net/global/images/product/motorcycle/Honda_Scoopy_2017/Honda_Scoopy_2017_L_3.jpg"
        ));
        courses.add(new MotorMatic(
                "7",
                "Beat street",
                "Honda",
                "4 stroke, Single selinder",
                "V-belt automatic",
                "110cc",
                "6,7 kw / 7.500 rpm",
                "PGM-FI",
                "4 liter",
                "Rp. 18.000.000",
                "https://d2pa5gi5n2e1an.cloudfront.net/global/images/product/motorcycle/Honda_Beat_Street_eSP/Honda_Beat_Street_eSP_L_1.jpg"
        ));
        courses.add(new MotorMatic(
                "8",
                "Beat Sporty",
                "Honda",
                "4 stroke, Single selinder",
                "V-belt automatic",
                "110cc",
                "6,7 kw / 7.500 rpm",
                "PGM-FI",
                "4 liter",
                "Rp. 18.000.000",
                "https://promomotorhonda.com/wp-content/uploads/2018/07/62005.png"
        ));
        courses.add(new MotorMatic(
                "9",
                "X-ride",
                "Yamaha",
                "4 stroke, Single selinder",
                "V-belt automatic",
                "110cc",
                "7 kw / 7.500 rpm",
                "Fuel Injection",
                "4 liter",
                "Rp. 18.000.000",
                "https://www.yamaha-motor.co.id/uploads/products/NciexRbkBj4ABjHWrMXH.png"
        ));
        courses.add(new MotorMatic(
                "10",
                "Mio s 125",
                "Yamaha",
                "4 stroke, Single selinder",
                "V-belt automatic",
                "125cc",
                "8,75 kw / 8.000 rpm",
                "Fuel Injection",
                "5 liter",
                "Rp. 16.000.000",
                "https://www.yamaha-motor.co.id/uploads/products/tCpouemtB8EzqgRjVmQ7.png"
        ));

        return courses;
    }
}
