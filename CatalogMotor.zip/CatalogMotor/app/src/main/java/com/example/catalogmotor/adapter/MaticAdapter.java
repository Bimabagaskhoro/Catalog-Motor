package com.example.catalogmotor.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.catalogmotor.CustomOnitemClickListener;
import com.example.catalogmotor.DetailSport.DetailMatic;
import com.example.catalogmotor.DetailSport.DetailSport;
import com.example.catalogmotor.R;
import com.example.catalogmotor.model.MotorBebek;
import com.example.catalogmotor.model.MotorMatic;

import java.util.ArrayList;

public class MaticAdapter extends RecyclerView.Adapter<MaticAdapter.MaticViewHolder>  {
    private ArrayList<MotorMatic> motorMatics;
    private Context context;

    private ArrayList<MotorMatic> getMotorBebeks(){
        return motorMatics;
    }
    public void setListBebekData(ArrayList<MotorMatic>listmotor){
        this.motorMatics = listmotor;
    }

    public MaticAdapter(Context context){
        this.context = context;
    }
    @NonNull
    @Override
    public MaticViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.items_matic,parent,false);
        return new MaticAdapter.MaticViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MaticViewHolder holder, int position) {
        holder.bind(motorMatics.get(position));
        holder.itemView.setOnClickListener(new CustomOnitemClickListener(position,((view, position1) -> {
            Intent intent = new Intent(context, DetailMatic.class);
            intent.putExtra(DetailMatic.EXTRA_COURSE,getMotorBebeks().get(position));
            context.startActivity(intent);
        })));
    }

    @Override
    public int getItemCount() {
        return motorMatics.size();
    }

    class MaticViewHolder extends RecyclerView.ViewHolder {
        final TextView tvMerk;
        final TextView tvproduk;
        final TextView tvIsiSilinder;
        final TextView tvBahanBakar;
        final TextView tvIsiTangki;
        final TextView tvHarga;
        final ImageView imgPoster;
        MaticViewHolder(@NonNull View itemView) {
            super(itemView);
            tvMerk = itemView.findViewById(R.id.tvMerkBebek);
            tvproduk = itemView.findViewById(R.id.tv_produk);
            tvIsiSilinder = itemView.findViewById(R.id.tv_silinder);
            tvBahanBakar = itemView.findViewById(R.id.tv_bahan_bakar);
            tvIsiTangki = itemView.findViewById(R.id.tv_Kapasitas_tangki);
            tvHarga = itemView.findViewById(R.id.tv_harga);
            imgPoster = itemView.findViewById(R.id.imgPosterBebek);
        }
        void bind(MotorMatic motorBebek){
            tvMerk.setText(motorBebek.getMerk());
            tvproduk.setText(motorBebek.getProduk());
            tvIsiSilinder.setText(motorBebek.getIsiSilinder());
            tvBahanBakar.setText(motorBebek.getSistemBahanBakar());
            tvIsiTangki.setText(motorBebek.getKapasitasTengki());
            tvHarga.setText(motorBebek.getHarga());
            Glide.with(itemView.getContext())
                    .load(motorBebek.getImgMotor())
                    .into(imgPoster);
        }
    }
}
