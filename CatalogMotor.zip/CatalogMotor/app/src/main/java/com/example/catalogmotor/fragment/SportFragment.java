package com.example.catalogmotor.fragment;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;

import com.example.catalogmotor.data.DataDummy;
import com.example.catalogmotor.R;
import com.example.catalogmotor.adapter.SportAdapter;

public class SportFragment extends Fragment {
    private RecyclerView rvCourse;
    private ProgressBar progressBar;
    private SportAdapter filmAdapter;
    public SportFragment() {
        // Required empty public constructor
    }
    public static Fragment newInstance() {
        return new SportFragment();
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_matic, container, false);
    }
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        rvCourse = view.findViewById(R.id.rv_matic);
    }
    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        if (getActivity()!=null){
            filmAdapter = new SportAdapter(getActivity());
            filmAdapter.setListBebekData(DataDummy.generateDummySport());

            rvCourse.setLayoutManager(new LinearLayoutManager(getContext()));
            rvCourse.setHasFixedSize(true);
            rvCourse.setAdapter(filmAdapter);

        }
    }
}
