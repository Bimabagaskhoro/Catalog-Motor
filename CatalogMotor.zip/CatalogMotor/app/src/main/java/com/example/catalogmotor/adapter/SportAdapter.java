package com.example.catalogmotor.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.catalogmotor.CustomOnitemClickListener;
import com.example.catalogmotor.DetailSport.DetailSport;
import com.example.catalogmotor.R;
import com.example.catalogmotor.model.MotorBebek;
import com.example.catalogmotor.model.MotorSport;

import java.util.ArrayList;

public class SportAdapter extends RecyclerView.Adapter<SportAdapter.SportViewHolder> {
    private ArrayList<MotorSport> motorSports;
    private Context context;

    private ArrayList<MotorSport> getMotorBebeks(){
        return motorSports;
    }
    public void setListBebekData(ArrayList<MotorSport>listmotor){
        this.motorSports = listmotor;
    }

    public SportAdapter(Context context){
        this.context = context;
    }
    @NonNull
    @Override
    public SportViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.items_sport,parent,false);
        return new SportAdapter.SportViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull SportViewHolder holder, int position) {
        holder.bind(motorSports.get(position));
        holder.itemView.setOnClickListener(new CustomOnitemClickListener(position,((view, position1) -> {
            Intent intent = new Intent(context, DetailSport.class);
            intent.putExtra(DetailSport.EXTRA_COURSE,getMotorBebeks().get(position));
            context.startActivity(intent);
        })));

    }

    @Override
    public int getItemCount() {
        return motorSports.size();
    }

    class SportViewHolder extends RecyclerView.ViewHolder {
        final TextView tvMerk;
        final TextView tvproduk;
        final TextView tvIsiSilinder;
        final TextView tvBahanBakar;
        final TextView tvIsiTangki;
        final TextView tvHarga;
        final ImageView imgPoster;
        SportViewHolder(@NonNull View itemView) {
            super(itemView);
            tvMerk = itemView.findViewById(R.id.tvMerkBebek);
            tvproduk = itemView.findViewById(R.id.tv_produk);
            tvIsiSilinder = itemView.findViewById(R.id.tv_silinder);
            tvBahanBakar = itemView.findViewById(R.id.tv_bahan_bakar);
            tvIsiTangki = itemView.findViewById(R.id.tv_Kapasitas_tangki);
            tvHarga = itemView.findViewById(R.id.tv_harga);
            imgPoster = itemView.findViewById(R.id.imgPosterBebek);
        }
        void bind(MotorSport motorBebek){
            tvMerk.setText(motorBebek.getMerk());
            tvproduk.setText(motorBebek.getProduk());
            tvIsiSilinder.setText(motorBebek.getIsiSilinder());
            tvBahanBakar.setText(motorBebek.getSistemBahanBakar());
            tvIsiTangki.setText(motorBebek.getKapasitasTengki());
            tvHarga.setText(motorBebek.getHarga());
            Glide.with(itemView.getContext())
                    .load(motorBebek.getImgMotor())
                    .into(imgPoster);
        }
    }
}
