package com.example.catalogmotor.DetailSport;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.catalogmotor.R;
import com.example.catalogmotor.model.MotorBebek;

public class DetailBebek extends AppCompatActivity {
    public static final String EXTRA_COURSE = "extra_course";
    private TextView tvMerk;
    private TextView tvproduk;
    private TextView tvIsiSilinder;
    private TextView tvBahanBakar;
    private TextView tvIsiTangki;
    private TextView tvJenisMesin;
    private TextView tvDayaMaks;
    private TextView tvTransmisi;
    private TextView tvHarga;
    private ImageView imgPoster;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_bebek);
        tvMerk = findViewById(R.id.tvMerkBebek);
        tvproduk = findViewById(R.id.tv_produk);
        tvIsiSilinder = findViewById(R.id.tv_silinder);
        tvBahanBakar = findViewById(R.id.tv_bahan_bakar);
        tvIsiTangki = findViewById(R.id.tv_Kapasitas_tangki);

        tvJenisMesin = findViewById(R.id.tv_jenis);
        tvDayaMaks = findViewById(R.id.tv_daya);
        tvTransmisi = findViewById(R.id.tv_transmisi);

        tvHarga = findViewById(R.id.tv_harga);
        imgPoster = findViewById(R.id.imageDetail);

        MotorBebek motorBebek = getIntent().getParcelableExtra(EXTRA_COURSE);
        assert motorBebek != null;

        Glide.with(DetailBebek.this)
                .load(motorBebek.getImgMotor())
                .into(imgPoster);

        tvMerk.setText(motorBebek.getMerk());
        tvproduk.setText(motorBebek.getProduk());
        tvIsiSilinder.setText(motorBebek.getIsiSilinder());
        tvBahanBakar.setText(motorBebek.getSistemBahanBakar());
        tvIsiTangki.setText(motorBebek.getKapasitasTengki());
        tvJenisMesin.setText(motorBebek.getJenisMesin());
        tvDayaMaks.setText(motorBebek.getDayaMaksimum());
        tvTransmisi.setText(motorBebek.getTransmisi());
        tvHarga.setText(motorBebek.getHarga());

    }
}
