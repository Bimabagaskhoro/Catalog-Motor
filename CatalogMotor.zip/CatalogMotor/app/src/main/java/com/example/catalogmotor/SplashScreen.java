package com.example.catalogmotor;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class SplashScreen extends AppCompatActivity {
    private ProgressBar progressBar;
    private TextView persentase;
    private int loading = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);
        progressBar = findViewById(R.id.progressBar);
        persentase = findViewById(R.id.persentase);
        progressBar.setProgress(0);

        final Handler handler = new Handler(){
            @Override
            public void handleMessage(Message msg) {
                super.handleMessage(msg);

                persentase.setText(String.valueOf(loading)+"%");
                if(loading == progressBar.getMax()){
                    Toast.makeText(getApplicationContext(), getString(R.string.app_name), Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(SplashScreen.this, MainActivity.class));
                    finish();
                }
                loading++;
            }
        };

        Thread thread = new Thread(() -> {
            try{
                for(int i=0; i<=progressBar.getMax(); i++){
                    progressBar.setProgress(i);
                    handler.sendMessage(handler.obtainMessage());
                    Thread.sleep(70);
                }
            }catch(InterruptedException ex){
                ex.printStackTrace();
            }
        });
        thread.start();
    }

}
