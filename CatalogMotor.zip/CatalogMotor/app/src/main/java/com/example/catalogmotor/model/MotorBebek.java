package com.example.catalogmotor.model;

import android.os.Parcel;
import android.os.Parcelable;

public class MotorBebek implements Parcelable {
    private String courseId;
    private String merk;
    private String produk;
    private String jenisMesin;
    private String transmisi;
    private String isiSilinder;
    private String dayaMaksimum;
    private String sistemBahanBakar;
    private String kapasitasTengki;
    private String harga;
    private String imgMotor;
    public MotorBebek(String courseId, String merk, String produk,
                      String jenisMesin, String transmisi, String isiSilinder,
                      String dayaMaksimum, String sistemBahanBakar, String kapasitasTengki,
                      String harga, String imgMotor) {
        this.courseId = courseId;
        this.merk = merk;
        this.produk = produk;
        this.jenisMesin = jenisMesin;
        this.transmisi = transmisi;
        this.isiSilinder = isiSilinder;
        this.dayaMaksimum = dayaMaksimum;
        this.sistemBahanBakar = sistemBahanBakar;
        this.kapasitasTengki = kapasitasTengki;
        this.harga = harga;
        this.imgMotor = imgMotor;
    }

    protected MotorBebek(Parcel in) {
        courseId = in.readString();
        merk = in.readString();
        produk = in.readString();
        jenisMesin = in.readString();
        transmisi = in.readString();
        isiSilinder = in.readString();
        dayaMaksimum = in.readString();
        sistemBahanBakar = in.readString();
        kapasitasTengki = in.readString();
        harga = in.readString();
        imgMotor = in.readString();
    }

    public static final Creator<MotorBebek> CREATOR = new Creator<MotorBebek>() {
        @Override
        public MotorBebek createFromParcel(Parcel in) {
            return new MotorBebek(in);
        }

        @Override
        public MotorBebek[] newArray(int size) {
            return new MotorBebek[size];
        }
    };

    public String getCourseId() {
        return courseId;
    }

    public void setCourseId(String courseId) {
        this.courseId = courseId;
    }

    public String getMerk() {
        return merk;
    }

    public void setMerk(String merk) {
        this.merk = merk;
    }

    public String getProduk() {
        return produk;
    }

    public void setProduk(String produk) {
        this.produk = produk;
    }

    public String getJenisMesin() {
        return jenisMesin;
    }

    public void setJenisMesin(String jenisMesin) {
        this.jenisMesin = jenisMesin;
    }

    public String getTransmisi() {
        return transmisi;
    }

    public void setTransmisi(String transmisi) {
        this.transmisi = transmisi;
    }

    public String getIsiSilinder() {
        return isiSilinder;
    }

    public void setIsiSilinder(String isiSilinder) {
        this.isiSilinder = isiSilinder;
    }

    public String getDayaMaksimum() {
        return dayaMaksimum;
    }

    public void setDayaMaksimum(String dayaMaksimum) {
        this.dayaMaksimum = dayaMaksimum;
    }

    public String getSistemBahanBakar() {
        return sistemBahanBakar;
    }

    public void setSistemBahanBakar(String sistemBahanBakar) {
        this.sistemBahanBakar = sistemBahanBakar;
    }

    public String getKapasitasTengki() {
        return kapasitasTengki;
    }

    public void setKapasitasTengki(String kapasitasTengki) {
        this.kapasitasTengki = kapasitasTengki;
    }

    public String getHarga() {
        return harga;
    }

    public void setHarga(String harga) {
        this.harga = harga;
    }

    public String getImgMotor() {
        return imgMotor;
    }

    public void setImgMotor(String imgMotor) {
        this.imgMotor = imgMotor;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(courseId);
        dest.writeString(merk);
        dest.writeString(produk);
        dest.writeString(jenisMesin);
        dest.writeString(transmisi);
        dest.writeString(isiSilinder);
        dest.writeString(dayaMaksimum);
        dest.writeString(sistemBahanBakar);
        dest.writeString(kapasitasTengki);
        dest.writeString(harga);
        dest.writeString(imgMotor);
    }
}
